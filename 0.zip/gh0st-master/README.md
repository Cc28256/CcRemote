gh0st beta 3.6 built on VS 2017

Referer:[https://yichinzhu.github.io/2017/09/09/build-gh0st/](https://yichinzhu.github.io/2017/09/09/build-gh0st/)
